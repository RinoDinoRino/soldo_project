import json
import os
import boto3
import sys
from botocore.vendored import requests

### This lambda calls takes the info from textract lambda
### and uses VINS to call an API. It then sends it to validate lambda


def api_dic_populate(current_car, car_dict, decoded_r):
    #populate vehicle dictionary with data from api
    
    kvp = {'year':9,'make':6,'model':8,'series':11,'trim':12,'body_class':23,'numb_doors':24,'vin_checker':4}
    for i, j in kvp.items():
        car_dict[current_car][i] = decoded_r["Results"][j]["Value"]
    
    if car_dict[current_car]['numb_doors'] == None:
         car_dict[current_car]['numb_doors'] = 4
    else:
        car_dict[current_car]['numb_doors'] = int(car_dict[current_car]['numb_doors'])
        
    if car_dict[current_car]['body_class'] == None:
        car_dict[current_car]['numb_doors'] = "n/a"

    #passive restraint
    if decoded_r["Results"][92]["Value"]:
        car_dict[current_car]['passive_restraint'] = 1
    else:
        car_dict[current_car]['passive_restraint'] = 0
        
    #ABS
    if not decoded_r["Results"][101]["Value"]:
        car_dict[current_car]['abs'] = 1
    else:
        car_dict[current_car]['abs'] = 0
    return (car_dict)


def lambda_handler(event, context):
    ### If successful, api data is added to dictionary
    print('event: ' + str(event))
    body =  event['body']
    print(body)
    body = body.replace("'","\"")
    full_dict = json.loads(body)

    try:
        print('dict prior to api: ' + str(full_dict))
        car_dict = full_dict['car_dict']
    
        print(list(full_dict))
        print(list(full_dict['car_dict']))
        
        ### For each car, gather data, check if api is online
        online = ""
        for current_car in list(full_dict['car_dict']):
            vin = full_dict['car_dict'][current_car]['VIN']
            url = 'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/' + vin +'?format=json'
            r = requests.get(url)
            if online != "200":
                online = str(r.status_code)
            full_dict['car_dict'][current_car]['decoded_r'] = json.loads(r.text)
            car_dict = api_dic_populate(current_car, car_dict, car_dict[current_car]['decoded_r'])
            del car_dict[current_car]['decoded_r']
        print("API Status Code: " + online)
    
        print('Dictionary after parse: ' +str(full_dict))
    
    except Exception as e:
        print("Failed API call")
        print(e)   
    
    return {
    'statusCode': 200,
    'body': json.dumps(full_dict),
    'APIstatusCode' : int(online)
    }

