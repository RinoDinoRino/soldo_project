import json
import os
import csv
import boto3
import sys

## Validates vehicle information and generates a quote
## converts data into 2 csv files

def validate_vin(current_car, car_dict): 
    reason = car_dict[current_car]['vin_checker']
    del car_dict[current_car]['vin_checker']
    print('reason: ' + reason[3:])
    if reason[0] != '0':
        print('Invalid VIN')
        return(False, 'Invalid VIN')  
    else:
        print('Valid VIN')
        return (True, 'All Good')
        
def validate_userinfo(user_info):
    #Validates info such as zip code
    if len(user_info['ZIPCODE']) != 5:
        return(False, "Invalid Zip")
    else:
        return(True, "Valid Zip")
        
def confirm_validity(full_dict):
     #Create vehicle validity variablem, we use validity as there are 2 care
    overall_validity = 1
    
    if full_dict['car_dict']['validity']:
        veh_validity = 1
    else:
        veh_validity = 0
        overall_validity = 0
    
    #Create User validity variable. We use user_invalid as we only have 1 user
    if not full_dict['user_dict']['user_invalid']:
        user_validity = 1
    else:
        user_validity = 0
        overall_validity = 0
    del full_dict['car_dict']['validity']
    
    return full_dict, veh_validity, user_validity, overall_validity         


def genQuote(full_dict):
    total = 0

    if full_dict['user_dict']['ADDITIONAL DRIVERS'] != 0:
        total += 24*full_dict['user_dict']['ADDITIONAL DRIVERS']
    if full_dict['user_dict']['MULTIPLE VEHICLE DISCOUNT'] == 1:
        total -= 12
    if full_dict['user_dict']['GOOD DRIVER DISCOUNT'] == 1:
        total -=8
    if full_dict['user_dict']['ACCIDENT FREE DISCOUNT'] == 1:
        total -= 16

    coverages = ['bodily_inj','property_dmg','personal_inj','uninsured_underinsured','comprehensive','collision','emerg_rd_serv','rental']
    print(str(list(full_dict['car_dict'])))

    for car in list(full_dict['car_dict']):
        car_prem = 0 
        if full_dict['car_dict'][car]['parked_home'] == 0:
            car_prem -= 25
        if int(full_dict['car_dict'][car]['numb_doors']) < 4:
            car_prem += 32
        if full_dict['car_dict'][car]['passive_restraint'] == 0:
            car_prem += 15
        if full_dict['car_dict'][car]['abs'] == 0:
            car_prem +=30
        for coverage in coverages:
            car_prem += int(full_dict['car_dict'][car][coverage+'_prem']) - 2
        full_dict['car_dict'][car]['gen_veh_prem'] = car_prem
        total += car_prem
       
    full_dict['user_dict']['gen_pol_prem'] = total
    total = "${:,.2f}".format(total)
        
    return full_dict, total

def convert_user_csv(user_dict, s3, policy_numb, validity):
    # Create User CSV and uploads it to S3
    TEMP_FILE = '/tmp/mycsvfile.csv'

    if validity:
        filename = "driverResults/driver_" + policy_numb + ".csv"
    else:
        filename = "driverResults/driver_" + policy_numb +"_invalid.csv"
        
    print(filename)
    user_file = open(TEMP_FILE,"w")
    with open(TEMP_FILE, "w") as u:
        w = csv.DictWriter( u, user_dict.keys() )
        w.writeheader()
        w.writerow(user_dict)
    user_file.close()
    
    resultbucket = os.environ['resultBucket']
    s3res = s3.Bucket(resultbucket).upload_file(TEMP_FILE, filename) 


def mergedict(a,b):
    #required for nested dictionary csv conversion
    a.update(b)
    return a
    

def convert_vehicle_csv(car_dict, s3, policy_numb, validity):
    #convert vehicle dictionary into csv and upload
    fields = ['vehicle']
    fields.extend(car_dict["1"].keys())
    TEMP_FILE = '/tmp/mycsvfile.csv'
    
    if validity:
        filename = "vehicleResults/vehicle_" + policy_numb + ".csv"
    else:
        filename = "vehicleResults/vehicle_" + policy_numb +"_invalid.csv"

    print(filename)
    user_file = open(TEMP_FILE,"w")
    with open(TEMP_FILE, "w") as f:
        w = csv.DictWriter( f, fields )
        w.writeheader()
        for k,d in car_dict.items():
            w.writerow(mergedict({'vehicle': k},d))
    
    resultbucket = os.environ['resultBucket_Oregon']
    s3res = s3.Bucket(resultbucket).upload_file(TEMP_FILE, filename) 

def lambda_handler(event, context):
    s3 = boto3.resource('s3')
    print(event)
    body = event['body']
    body = body.replace("'","\"")
    full_dict = json.loads(body)

    try:
        print('Dictionary before Validation: ' + str(full_dict))
        print(list(full_dict))
        car_dict = full_dict['car_dict']
        
        #Check information validity
        car_dict['validity'] = 1
        user_valid, user_reason = validate_userinfo(full_dict['user_dict'])
        
        #add validity marker to dictoinary
        if not user_valid:
            print("User Info:Invalid")
            full_dict['user_dict']['user_invalid'] = 1
            full_dict['user_dict']['invalid_reason'] = user_reason
    
        else:
            print("User Info: Valid")
            full_dict['user_dict']['user_invalid'] = 0 
            full_dict['user_dict']['invalid_reason'] = ""
    
            # Add invalid nested dictionary for easier extraction in the future
        if not user_valid:
            print("Adding Invalid Dictionary w/ reason:" + user_reason)
            full_dict['invalid'] = {'User':user_reason}
        
        print('car dict -1:')
        for car in list(full_dict['car_dict'])[:-1]:
            vin_valid, vin_reason = validate_vin(car, car_dict)
    
            if not vin_valid:
                print('car '+ car + ' VIN: Invalid')
                car_dict[car]['vin_invalid'] = 1 
                car_dict[car]['vin_invalid_reason'] = vin_reason
                if 'invalid' in full_dict:
                    full_dict['invalid']['car ' +  car] = vin_reason
                else: 
                    full_dict['invalid'] = {'car' + car:vin_reason}
                car_dict['validity'] = 0
            
            else:
                print('car '+ car + 'VIN: Valid')
                car_dict[car]['vin_invalid'] = 0
                car_dict[car]['vin_invalid_reason'] = ""
        
        print('Car Dictionary: '+str(car_dict))
        print('Full dictoinary: ' + str(full_dict))
        if 'invalid' in full_dict:
            print('Invalid Dictionary: ' + str(full_dict['invalid']))
        
        if 'invalid' in full_dict:
            invalid_dict = {}
            invalid_dict = full_dict['invalid']
            del full_dict['invalid']
        
        full_dict, veh_validity, user_validity, overall_validity = confirm_validity(full_dict)
        policy_numb = full_dict['user_dict']['POLICY NUMBER:']
    
        
        if user_validity & veh_validity:
            # Populate sqs and sns with correct info
            print('GENERATING QUOTE')
            full_dict, total = genQuote(full_dict)   
            snsbody = 'Your estimated quote is ' + total
            sqsbody = "All "
    
        else: 
            #SQS invalid info
            invalid_msg = str(invalid_dict).replace("{","").replace("}", "").replace('"',"")
            sqsbody = 'Invalid Reason(s): ' + str(invalid_dict)
    
            #SNS info
            snsbody = 'Invalid Reason(s): ' + invalid_msg
    
        print('Starting csv conversion')
        convert_user_csv(full_dict['user_dict'],s3,policy_numb,user_validity)
        convert_vehicle_csv(full_dict['car_dict'],s3,policy_numb,veh_validity)
    
    except Exception as e:
        print("Failed in Conversion")
        print(e)
        
    return {
        'statusCode': 200,
        'snsbody' : json.dumps(snsbody),
        'sqsbody' : json.dumps(sqsbody),
        'validity' : overall_validity
    }
