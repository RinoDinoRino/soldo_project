import json
import boto3
import os
import sys
from trp import Document

### This lambda will call textract and extract data through forms and tables
### The data will be passed to the lambda responsible for the VIN API


def call_textract(textract, s3BucketName, documentName):
    # Call Amazon Textract and collects Forms and Tables
    response = textract.analyze_document(
        Document={
            'S3Object': {
                'Bucket': s3BucketName,
                'Name': documentName
            }
        },
        FeatureTypes=["TABLES","FORMS"])
    return(Document(response))

def get_form_info(doc):
    # Populate user dictionary with data from the form category
    for page in doc.pages:
        user_dict = {}
        keys = ('NAME:','INSURED EMAIL:','INSURED PHONE NUMBER:','POLICY NUMBER:')
        for key in keys:
            field = str(page.form.getFieldByKey(key).value)
            user_dict[key] = field

        #fix policy number
        user_dict['POLICY NUMBER:'] = str(user_dict['POLICY NUMBER:']).replace("-", "").strip()
        
        #inserting current total policy premium into user_dict
        #have to adjust for the dollar sign
        tot_pol_prem =  int(str(page.form.getFieldByKey("TOTAL POLICY PREMIUM:").value).replace("$","").replace(",","").strip())
        user_dict['CURRENT TOTAL POLICY PREMIUM:'] = tot_pol_prem
        
        #get address
        address = ''.join(str(page.form.getFieldByKey("ADDRESS:").value).split()[:3])
        user_dict['ADDRESS'] = address
        
        #putting zipcode in user_dict
        zipcode =  str(page.form.getFieldByKey("ADDRESS:").value).split()[-1]
        user_dict['ZIPCODE'] = zipcode
        
        #Putting policy year in user_dict
        pol_year =  str(page.form.getFieldByKey("DATE POLICY ISSUED:").value).split()[-1]
        user_dict['POLICY YEAR'] = pol_year
    

        #Putting Additional drivers in user_dict (try block cause does not always exists
        try:
            additional_driver =  str(page.form.getFieldByKey("ADDITIONAL DRIVERS:").value)
            user_dict['ADDITIONAL DRIVERS'] = (additional_driver.count(',') + 1)
        except:
             user_dict['ADDITIONAL DRIVERS'] = 0
             
        #Adding Discounts to user_dict
        multiple_vehicle =  str(page.form.getFieldByKey("DISCOUNTS:").value)
        if multiple_vehicle.count("MULTIPLE"):
            user_dict['MULTIPLE VEHICLE DISCOUNT'] = 1
        else:
            user_dict['MULTIPLE VEHICLE DISCOUNT'] = 0
        
        good_driver =  str(page.form.getFieldByKey("DISCOUNTS:").value)
        if good_driver.count("GOOD DRIVER"):
            user_dict['GOOD DRIVER DISCOUNT'] = 1
        else:
            user_dict['GOOD DRIVER DISCOUNT'] = 0
        
        accident_free =  str(page.form.getFieldByKey("DISCOUNTS:").value)
        if accident_free.count("ACCIDENT FREE"):
            user_dict['ACCIDENT FREE DISCOUNT'] = 1
        else:
            user_dict['ACCIDENT FREE DISCOUNT'] = 0
        
        loss_payee =  str(page.form.getFieldByKey("LOSS PAYEE:").value)
        if not loss_payee:
            user_dict['LOSS PAYEE:'] = ""
        else:
            user_dict['LOSS PAYEE:'] = loss_payee.split(',')[0]
        
        print(user_dict)
        return(user_dict)    
    



def get_vehicle_table_data(page, car_count, user_dict):
    #Gathers VIN data from table 2 
    car_dict={}    
    car_counter = 1
    for car in range(car_count):
        current_car = str(car+1)
        car_dict[current_car] = {'POLICY NUMBER:':user_dict['POLICY NUMBER:']}
        
        # Gather VIN data from vehicle table (table 2)
        car_dict[current_car]['VIN'] = str(page.tables[1].rows[car+1].cells[4].text.strip())
        
        #checked if car is parked at home address
        if user_dict['ADDRESS'] == str(page.tables[1].rows[car+1].cells[5].text.replace(' ','')).upper():
            car_dict[current_car]['parked_home'] = 1
        else:
            car_dict[current_car]['parked_home'] = 0

        car_dict = get_coverages(car_counter, current_car, car_dict, page.tables[0])
        car_counter += 1
        
    return(car_dict)


def get_coverages(car_counter, current_car, car_dict,table):
    # Get coverages data from Table 1
    
    row_counter= 1
    cov_keys = ['bodily_inj','property_dmg','personal_inj','uninsured_underinsured','comprehensive','collision','emerg_rd_serv','rental']
    cov_col = 1
    
    for cov_key in cov_keys:
        if cov_key == 'bodily_inj':
            car_dict[current_car][cov_key+ '_lim_perperson'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip()).split("/")[0]
            car_dict[current_car][cov_key+ '_lim_peroccurence'] =str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip()).split("/")[1]

        elif cov_key == "uninsured_underinsured":
            car_dict[current_car]['uninsured_lim'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip()).split("/")[0]
            car_dict[current_car]['underinsured_lim'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip()).split("/")[1]
            
        elif cov_key == "comprehensive" or cov_key == "collision":
            car_dict[current_car][cov_key+'_deductible'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip()).split(" ")[0]
        
        elif cov_key == 'rental':
            car_dict[current_car][cov_key+'_day'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").replace("/"," ").strip()).split(" ")[0]
            car_dict[current_car][cov_key+'_max'] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").replace("/"," ").strip()).split(" ")[-2]
           
        else:
            car_dict[current_car][cov_key + "_lim"] = str(table.rows[row_counter].cells[cov_col].text.replace('$','').replace(",","").strip())
        
        car_dict[current_car][cov_key + "_prem"] = str(table.rows[row_counter].cells[car_counter+1].text.replace('$','').replace(",","").strip())
       
        if car_dict[current_car][cov_key + "_prem"] == '':
            car_dict[current_car][cov_key + "_prem"] = 0
        elif cov_key != 'emerg_rd_serv':
            car_dict[current_car][cov_key + "_prem"] = int(car_dict[current_car][cov_key + "_prem"])
       
        row_counter += 1
        
    car_dict[current_car]['curr_veh_prem'] = str(table.rows[9].cells[car_counter+1].text.replace('$','').strip())
    return(car_dict)
    

def lambda_handler(event, context):
    ### If successful, a dictionary should be returned with info about the user
    ### and vechile found on the page
    print(event)
    
    s3BucketName = event['detail']['requestParameters']['bucketName']
    documentName = event['detail']['requestParameters']['key']
    
    print("Bucket Name: " + s3BucketName)
    print("documentName: " + documentName)
    
    textract = boto3.client('textract')
    s3 = boto3.resource('s3')
    sqs = boto3.client('sqs')

    try:
        ### FORM DATA COLLECTION
        doc = call_textract(textract, s3BucketName, documentName)
        
        #Gather user info from forms
        full_dict = {}
        full_dict['user_dict'] = get_form_info(doc)
        user_dict = full_dict['user_dict']

    
        
        #convert user info to CSV, save policy number for both conversions
        policy_numb = user_dict["POLICY NUMBER:"].replace("-", "").strip()
    
        ### TABLE DATA COLLECTION 
        car_count = len(doc.pages[0].tables[1].rows) - 1
        
        # Gather the VINS and parked_at_home from the table
        car_dict = get_vehicle_table_data(doc.pages[0], car_count, user_dict)
        print(car_dict)
        user_dict['Number Cars on Policy:'] = len(car_dict)
        full_dict['car_dict'] = car_dict 
          

    
    except Exception as e:
        print("Failed extraction")
        print(e)

    return {
        'statusCode': 200,
        'body': json.dumps(full_dict)
    }